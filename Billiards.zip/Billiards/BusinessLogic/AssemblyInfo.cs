using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

[assembly: InternalsVisibleTo("BusinessLogicTest")]
[assembly: ComVisible(false)]
[assembly: Guid("B2A90084-F3B3-4DF6-9B46-C0C81C9833F0")]