﻿using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

[assembly: InternalsVisibleTo("DataTest")]
[assembly: ComVisible(false)]
[assembly: Guid("D452A29B-9DEB-4579-8814-BA7AEBCC0EB7")]