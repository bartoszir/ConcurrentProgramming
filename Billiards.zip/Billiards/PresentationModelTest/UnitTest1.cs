﻿namespace PresentationModelTest
{
    public class UnitTest1
    {
        [Fact]
        public void Test1()
        {
            Assert.NotEqual(2, 1);
        }
    }
}
