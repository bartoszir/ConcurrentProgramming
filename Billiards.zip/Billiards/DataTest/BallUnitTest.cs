namespace Billiards.DataTest
{
	public class BallUnitTest
	{
		[Fact]
		public void MoveTestMethod()
		{
			
			Assert.Equal(1, 1);
		}
	}
}