using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

[assembly: InternalsVisibleTo("PresentationViewModelTest")]
[assembly: ComVisible(false)]
[assembly: Guid("02C46BA4-25ED-4412-814E-EA41456EBE5E")]