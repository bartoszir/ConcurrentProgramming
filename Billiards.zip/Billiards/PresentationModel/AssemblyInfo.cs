using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

[assembly: InternalsVisibleTo("PresentationModelTest")]
[assembly: ComVisible(false)]
[assembly: Guid("CCCCBF13-967B-4E7F-97C2-44FBF028F5B0")]